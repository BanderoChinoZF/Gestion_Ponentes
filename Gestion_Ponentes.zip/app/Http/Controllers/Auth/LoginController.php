<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    public function redirectPath()
    {
      if( Auth()->user() ){
        if(Auth()->user()->tipo_usuario == 1)
        {
          return '/Administrador/inicio';
        }else if(Auth()->user()->tipo_usuario == 2)
        {
          return '/Tallerista/inicio';
        }else if(Auth()->user()->tipo_usuario == 3)
        {
          return '/RecursosHumanos/inicio';
        }
      }

      return '/';
      
    }


    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }
}
