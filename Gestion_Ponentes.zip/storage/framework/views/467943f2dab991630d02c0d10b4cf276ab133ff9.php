

<?php $__env->startSection('content'); ?>


<div class="col-10 offset-1">
    <div class="py-8 text-center text-xl font-bold uppercase">Talleristas</div>
    <div class="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
        <?php $__currentLoopData = $talleristas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tallerista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card h-100">
                <img class="img-fluid rounded-start" src="<?php echo e(asset('img/sin_imagen.png')); ?>" alt="Card image cap">
                <div class="card-body">
                    <div class="capitalize text-center">
                        <strong> <?php echo e($tallerista->nombre_tallerista); ?> </strong>
                    </div>
                    <div class="capitalize text-center py-3">
                        <?php echo e($tallerista->lugar); ?>

                    </div>
                </div>
                <div class="card-footer">
                    <a href="<?php echo e(route('Administrador.sesiones.buscar',$tallerista->id)); ?>" 
                        class="btn btn-block normal-case text-white" style="background-color: #da2c4e;">
                        <i class="fas fa-folder-open"> Detalles</i>
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Gestion_Ponentes\resources\views/Administrador/talleristas.blade.php ENDPATH**/ ?>