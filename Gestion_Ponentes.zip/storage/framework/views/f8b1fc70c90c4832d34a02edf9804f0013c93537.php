

<?php $__env->startSection('content'); ?>

  
  <div class="flex items-center justify-start px-8 py-8 gap-x-8">
    <div class="rounded-full h-20 w-20">
      <img src="<?php echo e(asset('img/sin_imagen.png')); ?>" alt=""  class="rounded-full h-20 w-20">
    </div>
    <div class="text-center text-lg lg:text-xl font-bold flex h-20 items-center justify-center">
      <?php echo e($tallerista->nombre_tallerista); ?>

    </div>
  </div>

  
  <div class="card-body text-wrap bg-body px-8 mx-auto">
    
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, voluptatibus non obcaecati enim odio praesentium fuga earum ducimus saepe sequi asperiores facere dolores nisi exercitationem, nobis dolorem dolorum, corporis dolore.</p>
  </div>
  

  
  
  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sesiones', ['tallerista_id' => $tallerista->id])->html();
} elseif ($_instance->childHasBeenRendered('rwyS6RZ')) {
    $componentId = $_instance->getRenderedChildComponentId('rwyS6RZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('rwyS6RZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rwyS6RZ');
} else {
    $response = \Livewire\Livewire::mount('sesiones', ['tallerista_id' => $tallerista->id]);
    $html = $response->html();
    $_instance->logRenderedChild('rwyS6RZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

  
  <div class="row col-12">
    <div class="col-12 col-md-6 px-0 mx-auto" id="chart1"></div>
    <div class="col-12 col-md-6 px-0 mx-auto" id="chart2"></div>
    <div class="col-12 col-md-6 px-0 mx-auto" id="chart3"></div>
    <div class="col-12 col-md-6 px-0 mx-auto" id="chart4"></div>
    <div class="col-12 col-md-6 px-0 mx-auto" id="chart5"></div>
    <div class="col-12 col-md-6 px-0 mx-auto" id="chart6"></div>
  </div>

  <br>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script type="text/javascript">
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      //Grafica 1
      var data = google.visualization.arrayToDataTable([
        ['Respuesta', 'Cantidad de respuestas'],
        <?php echo $chartData1 ?>
      ]);

      var options = { 
        title: "<?php echo $chartTitle1 ?>"
      };
      var chart = new google.visualization.PieChart(document.getElementById('chart1'));
      chart.draw(data, options);

      //Grafica 2
      var data = google.visualization.arrayToDataTable([
        ['Respuesta', 'Cantidad de respuestas'],
        <?php echo $chartData2 ?>
      ]);

      var options = { title: "<?php echo $chartTitle2 ?>" };
      var chart = new google.visualization.PieChart(document.getElementById('chart2'));
      chart.draw(data, options);

      //Grafica 3
      var data = google.visualization.arrayToDataTable([
        ['Respuesta', 'Cantidad de respuestas'],
        <?php echo $chartData3 ?>
      ]);

      var options = { title: "<?php echo $chartTitle3 ?>" };
      var chart = new google.visualization.PieChart(document.getElementById('chart3'));
      chart.draw(data, options);

      //Grafica 4
      var data = google.visualization.arrayToDataTable([
        ['Respuesta', 'Cantidad de respuestas'],
        <?php echo $chartData4 ?>
      ]);

      var options = { title: "<?php echo $chartTitle4 ?>" };
      var chart = new google.visualization.PieChart(document.getElementById('chart4'));
      chart.draw(data, options);
    }
  </script>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Gestion_Ponentes\resources\views/Administrador/talleristas_sesiones.blade.php ENDPATH**/ ?>