<div>
    
    <div class="card-header text-center font-sans text-xl font-bold">
      SESIONES
      <div class="d-flex justify-content-end">
        <input wire:model="search" type="text" class="form-control" placeholder="Ingrese la fecha">
      </div>
    </div>
    <div class="card-body">
        
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          <?php $__currentLoopData = $sesiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
              <div class="card h-100 p-0">
                
                
                <img src="<?php if($a->ruta_imagen): ?>
                  <?php echo e(asset($a->ruta_imagen)); ?>

                <?php else: ?>
                  <?php echo e(asset('img/sin_imagen.png')); ?>

                <?php endif; ?>" alt="" class="img-fluid rounded h-40" style="object-fit: cover;">
                <div class="card-body">
                  <div class="d-flex justify-content-between">
                    <label class="py-2"><strong>Sesi&oacute;n</strong></label>
                    <label class="py-2"><?php echo e($a->idsesion); ?></label>
                  </div>
                  <div class="d-flex justify-content-between">
                    <label class="py-2"><strong>Tallerista</strong></label>
                    <label class="py-2"><?php echo e($a->tallerista); ?></label>
                  </div>
                  
                  <div class="d-flex justify-content-end">
                    <label class="text-sm text-muted py-2"><?php echo e($a->fecha); ?></label>
                  </div>
                </div>
                <div class="card-footer">
                  <a href="<?php echo e(route('Administrador.sesiones.showSesion', $a->idsesion)); ?>" class="btn btn-block text-white normal-case rounded-pill" style="background-color: #da2c4e">
                    Detalles
                  </a>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
    </div>
    <div class="card-footer">
        <?php echo e($sesiones->links()); ?>

    </div>
</div>
<?php /**PATH D:\xampp\htdocs\Gestion_Ponentes\resources\views/livewire/sesiones.blade.php ENDPATH**/ ?>