

<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="row justify-content-center">
    <div class="col-12 col-md-8 col-lg-9 col-xl-10 p-1 p-lg-4">
      <div class="card-header text-center font-sans text-xl font-bold">
        SESIONES
      </div>
      <div class="card-body">
        
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          <?php $__currentLoopData = $sesiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
              <div class="card h-100 p-0">
                
                <img src="<?php echo e(asset('img/sin_imagen.png')); ?>" class="card-img-top" alt="Sesion sin imagen">
                <div class="card-body">
                  <h5 class="card-title"><strong>Sesi&oacute;n</strong> <?php echo e($a->idsesion); ?></h5>
                  <strong>Tallerista</strong> <?php echo e($a->tallerista); ?>

                  <small class="text-muted"><?php echo e($a->fecha); ?></small>
                </div>
                <div class="card-footer">
                  <a href="<?php echo e(route('Administrador.sesiones.showSesion', $a->idsesion)); ?>" class="btn btn-block" style="background-color: #da2c4e"> detalles</a>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <br><br><br>
        
      </div>
      <div class="card-footer">
        <?php echo e($sesiones->links()); ?>

      </div>
    </div>
    
    <div class="col col-md-4 col-lg-3 col-xl-2 p-1 p-lg-4">
      <div class="card p-0 p-md-2">
        <div class="card-header text-light text-center" style="background-color: #da2c4e;">
          <h2 class="font-sans text-lg"> Talleristas </h2>
        </div>
        <?php $__currentLoopData = $talleristas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tallerista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card-header hover:bg-red-50">
          <a href="<?php echo e(route('Administrador.sesiones.buscar',$tallerista->id)); ?>" class="text-sm">
            <?php echo e($tallerista->nombre_tallerista); ?>

          </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>

  <div class="col-12 col-md-8 col-lg-9 col-xl-10 d-flex justify-content-end p-4">
    <div class="btn-group" role="group">
      <a href="<?php echo e(route('Administrador.sesiones.pdf.download')); ?>" class="btn" style="background-color: #da2c4e"> PDF </a>
      <a href="<?php echo e(route('Administrador.sesiones.excel.download')); ?>" class="btn" style="background-color: aqua"> Excel</a>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Gestion_Ponentes\resources\views/Administrador/sesiones.blade.php ENDPATH**/ ?>