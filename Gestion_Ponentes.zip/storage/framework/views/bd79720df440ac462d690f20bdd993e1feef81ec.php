<!-- Modal -->
<div class="modal fade" id="filtrosModal" tabindex="-1" role="dialog" aria-labelledby="filtrosModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
      <div class="modal-content">
      <div class="modal-header text-center text-light text-xl font-bold" style="background-color: #da2c4e">
          <h5 class="text-center" id="filtrosModalLabel">Seleccionar los filtros deseados</h5>
          <button type="button" class="close" data-mdb-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
      </div>
      <div class="modal-body">
        
        <div class="grid grid-cols-3 gap-x-1 gap-y-2">
          <button class="btn bg-blue-500 hover:bg-blue-700 text-sm text-white font-bold normal-case" type="button" data-mdb-toggle="collapse" data-mdb-target="#collapseUbicacion" aria-expanded="false" aria-controls="collapseExample">
            Ubicaci&oacute;n
          </button>
          <button class="btn bg-blue-500 hover:bg-blue-700 text-sm text-white font-bold normal-case" type="button" data-mdb-toggle="collapse" data-mdb-target="#collapseDepartamento" aria-expanded="false" aria-controls="collapseExample">
            Departamentos
          </button>
          <button class="btn bg-blue-500 hover:bg-blue-700 text-sm text-white font-bold normal-case" type="button" data-mdb-toggle="collapse" data-mdb-target="#collapseJefe" aria-expanded="false" aria-controls="collapseExample">
            Jefe directo
          </button>
          <button class="btn bg-blue-500 hover:bg-blue-700 text-sm text-white font-bold normal-case" type="button" data-mdb-toggle="collapse" data-mdb-target="#collapseTipos" aria-expanded="false" aria-controls="collapseExample">
            Tipos
          </button>
          <button class="btn bg-blue-500 hover:bg-blue-700 text-sm text-white font-bold normal-case" type="button" data-mdb-toggle="collapse" data-mdb-target="#collapsePuestos" aria-expanded="false" aria-controls="collapseExample">
            Puestos
          </button>
          <a href="<?php echo e(route('Administrador.asistentes.index')); ?>" class="btn bg-blue-500 hover:bg-blue-700 text-sm text-white font-bold normal-case">
            Sin filtros
          </a>
        </div>
        
        <div class="py-1 px-2">  
          <div class="collapse py-4" id="collapseUbicacion">
            <div class="overflow-y-auto h-62">
              <?php $__currentLoopData = $ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->ubicacion != null): ?>
                <a href="<?php echo e(route('Administrador.asistentes.filtros',['ubicacion',str_replace(' ', '+', $item->ubicacion)])); ?> " class="btn-block bg-transparent hover:bg-blue-500 text-blue-500 font-semibold hover:text-blue-700 py-2 px-4 border border-blue-500 hover:border-transparent rounded"><?php echo e($item->ubicacion); ?></a>  
                
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
          
          <div class="collapse py-4" id="collapseDepartamento">
            <div class="overflow-y-auto h-62">
              <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->departamento != null): ?>
                  <a href=" <?php echo e(route('Administrador.asistentes.filtros',['departamento',str_replace(' ', '+', $item->departamento)])); ?> " class="btn-block bg-transparent hover:bg-blue-500 text-blue-500 font-semibold hover:text-blue-700 py-2 px-4 border border-blue-500 hover:border-transparent rounded"><?php echo e($item->departamento); ?></a>  
                
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
          
          <div class="collapse py-4" id="collapseJefe">
            <div class="overflow-y-auto h-62">
              <?php $__currentLoopData = $jefes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->jefe_inmediato != null): ?>
                  <a href=" <?php echo e(route('Administrador.asistentes.filtros',['jefe_inmediato',str_replace(' ', '+', $item->jefe_inmediato)])); ?> " class="btn-block bg-transparent hover:bg-blue-500 text-blue-500 font-semibold hover:text-blue-700 py-2 px-4 border border-blue-500 hover:border-transparent rounded"><?php echo e($item->jefe_inmediato); ?></a>  
                
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
          
          <div class="collapse py-4" id="collapsePuestos">
            <div class="overflow-y-auto h-62">
              <?php $__currentLoopData = $puestos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->puesto != null): ?>
                  <a href=" <?php echo e(route('Administrador.asistentes.filtros',['puesto',str_replace(' ', '+', $item->puesto)])); ?> " class="btn-block bg-transparent hover:bg-blue-500 text-blue-500 font-semibold hover:text-blue-700 py-2 px-4 border border-blue-500 hover:border-transparent rounded"><?php echo e($item->puesto); ?></a>  
                
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
          
          <div class="collapse py-4" id="collapseTipos">
            <div class="overflow-y-auto h-62">
              <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->tipo != null): ?>
                  <a href=" <?php echo e(route('Administrador.asistentes.filtros',['tipo',str_replace(' ', '+', $item->tipo)])); ?> " class="btn-block bg-transparent hover:bg-blue-500 text-blue-500 font-semibold hover:text-blue-700 py-2 px-4 border border-blue-500 hover:border-transparent rounded"><?php echo e($item->tipo); ?></a>  
                
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>

      <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Cerrar</button>
          
      </div>
      </div>
  </div>
</div><?php /**PATH D:\xampp\htdocs\Gestion_Ponentes\resources\views/components/pop-up.blade.php ENDPATH**/ ?>