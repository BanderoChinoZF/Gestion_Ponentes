<div class="card-header col-12">
  <div class="table-responsive">
    <table id="tabla_sesion_asistentes" class="table table-striped">
      <caption>Asistentes a la sesi&oacute;n</caption>
      <thead>
          <tr>
              <th>Id</th>
              <th>Nombre </th>
              <th>Ubicación </th>
              <th class="d-none d-md-table-cell">Departamento </th>
              <th class="d-none d-md-table-cell">Id sesión </th>
          </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $asistentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <th><?php echo e($asistente->id_empleado); ?> </th>
              <td><?php echo e($asistente->nombre_completo); ?></td>
              <td><?php echo e($asistente->ubicacion); ?></td>
              <td class="d-none d-md-table-cell"><?php echo e($asistente->departamento); ?></td>
              <td class="d-none d-md-table-cell"><?php echo e($asistente->idsesion); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div><?php /**PATH D:\xampp\htdocs\Gestion_Ponentes\resources\views/Administrador/exportar_asistentes.blade.php ENDPATH**/ ?>