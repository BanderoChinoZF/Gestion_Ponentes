<!-- Modal -->
<div class="modal fade" id="filtrosModal" tabindex="-1" role="dialog" aria-labelledby="filtrosModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="filtrosModalLabel">Seleccionar los filtros deseados</h5>
            <button type="button" class="close" data-mdb-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            
            <a href="<?php echo e(route('Administrador.asistentes.index', 'ubicaciones')); ?>" class="btn btn-block">Filtrar por ubicaci&oacute;n</a>
            <a href="<?php echo e(route('Administrador.asistentes.index', 'jefes')); ?>" class="btn btn-block">Filtrar por jefe inmediato</a>
            <a href="<?php echo e(route('Administrador.asistentes.index', 'puestos')); ?>" class="btn btn-block">Filtrar por puesto</a>
            <a href="<?php echo e(route('Administrador.asistentes.index', 'tipos')); ?>" class="btn btn-block">Filtrar por tipo</a>
            <a href="<?php echo e(route('Administrador.asistentes.index', 'epartamntos')); ?>" class="btn btn-block">Filtrar por departamento</a>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Cerrar</button>
            <button type="button" class="btn btn-primary">Mostrar</button>
        </div>
        </div>
    </div>
</div><?php /**PATH D:\xampp\htdocs\Gestion_Ponentes\resources\views/Administrador/modal/filtros.blade.php ENDPATH**/ ?>