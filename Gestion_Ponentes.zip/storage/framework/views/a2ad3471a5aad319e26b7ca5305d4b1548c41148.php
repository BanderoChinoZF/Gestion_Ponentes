

<?php $__env->startSection('content'); ?>
<?php if($filtro != null): ?>
<div class="py-8 text-center text-xl font-bold uppercase"><?php echo e($filtro); ?> <?php echo e($valor); ?></div>
<?php else: ?>
    <div class="py-8 text-center text-xl font-bold uppercase">Empleados</div>
<?php endif; ?>

<div class="col-10 offset-1">
    <div class="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
        <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card h-100">
                <img class="img-fluid rounded-start" src="<?php echo e(asset('img/sin_imagen.png')); ?>" alt="Card image cap">
                <div class="card-body">
                    <div class="capitalize">
                        <?php echo e($empleado->nombre_completo); ?>

                    </div>
                </div>
                <div class="card-footer">
                    <a href="<?php echo e(route('Administrador.asistentes.show', $empleado->id_empleado)); ?>" 
                        class="btn btn-block normal-case rounded-none bg-blue-600 hover:bg-red-600 text-white">
                        <i class="fas fa-folder-open"> Detalles</i>
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<div class="py-4 px-2 col-10">
    <small> <?php echo e($empleados->onEachSide(1)->links()); ?> </small>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Gestion_Ponentes\resources\views/Administrador/empleados.blade.php ENDPATH**/ ?>