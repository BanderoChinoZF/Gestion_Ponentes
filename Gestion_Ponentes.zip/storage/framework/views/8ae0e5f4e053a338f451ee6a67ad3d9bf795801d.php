
<?php $__env->startSection('content'); ?>
  
  <div class="flex items-center justify-start px-8 py-8 gap-x-8">
    
    <div class="rounded-full h-20 w-20 flex items-center justify-center">
      <a href="<?php echo e(url()->previous()); ?>" 
        class="btn rounded-full normal-case text-light" 
        style="background-color: #da2c4e;">
        <i class="far fa-arrow-alt-circle-left"></i>
      </a>
    </div>
    <div class="text-center text-lg font-bold flex h-20 items-center justify-center">Sesion <?php echo e($sesion->idsesion); ?> </div>
    <div class="text-center text-lg font-bold flex h-20 items-center justify-center">Tallerista: <?php echo e($sesion->tallerista); ?> </div>
  </div>

  <div class="card p-2 p-md-4 mb-4">
    <div class="card-body">

        
      <div class="row col-12">
        <div class="col-12 col-md-6 px-0 mx-auto" id="chart1"></div>
        <div class="col-12 col-md-6 px-0 mx-auto" id="chart2"></div>
        <div class="col-12 col-md-6 px-0 mx-auto" id="chart3"></div>
        <div class="col-12 col-md-6 px-0 mx-auto" id="chart4"></div>
        <div class="col-12 col-md-6 px-0 mx-auto" id="chart5"></div>
        <div class="col-12 col-md-6 px-0 mx-auto" id="chart6"></div>
      </div>

      
      <div class="card-header col-12 mb-4">
        <div class="table-responsive">
          <table id="tabla_sesion_asistentes" class="table table-striped">
            <caption>Asistentes a la sesi&oacute;n</caption>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombre </th>
                    <th>Ubicación </th>
                    <th class="d-none d-md-table-cell">Departamento </th>
                    <th class="d-none d-md-table-cell">Id sesión </th>
                </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $asistentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($asistente->id_empleado); ?> </th>
                    <td><?php echo e($asistente->nombre_completo); ?></td>
                    <td><?php echo e($asistente->ubicacion); ?></td>
                    <td class="d-none d-md-table-cell"><?php echo e($asistente->departamento); ?></td>
                    <td class="d-none d-md-table-cell"><?php echo e($asistente->idsesion); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          
          <div class="col-12 d-flex justify-content-end p-4">
            <div class="btn-group" role="group">
              <a href="<?php echo e(route('Administrador.asistentes.excel.download' , $sesion->idsesion)); ?>" class="btn text-white normal-case" style="background-color: #107c41">
                <i class="fas fa-file-excel"></i> Excel
              </a>
            </div>
          </div>
          
        </div>
      </div>

             
      <div class="bg-body row">
        <div class="card-header bg-body text-wrap rouded fw-bold">Lo mejor de la sesi&oacute;n</div>
        <div class="card-body text-wrap bg-body px-8 pt-0">
          <p><?php echo e($sesion->comentario1); ?></p>
        </div>
      </div>
      <div class="bg-body row">
        <div class="card-header bg-body text-wrap rouded fw-bold">¿Qu&eacute; &aacute;reas de oportunidad se presentaron?</div>
        <div class="card-body text-wrap bg-body px-8 pt-0">
          <p><?php echo e($sesion->comentario2); ?></p>
        </div>
      </div>
      <div class="bg-body row">
        <div class="card-header text-wrap bg-body fw-bold">¿Qu&eacute; situaciones de AHLS se expresaron?</div>
        <div class="card-body text-wrap bg-body px-8 pt-0">
          <p><?php echo e($sesion->comentario3); ?></p>
        </div>
      </div>
      <div class="bg-body row">
        <div class="card-header text-wrap bg-body fw-bold">¿Qu&eacute; elementos de la cultura organizacional resaltaron?</div>
        <div class="card-body text-wrap bg-body px-8 pt-0">
          <p><?php echo e($sesion->comentario4); ?></p>
        </div>
      </div>

    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script type="text/javascript">
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      //Grafica 1
      var data = google.visualization.arrayToDataTable([
        ['Respuesta', 'Cantidad de respuestas'],
        <?php echo $chartData1 ?>
      ]);

      var options = { 
        title: "<?php echo $chartTitle1 ?>"
      };
      var chart = new google.visualization.PieChart(document.getElementById('chart1'));
      chart.draw(data, options);

      //Grafica 2
      var data = google.visualization.arrayToDataTable([
        ['Respuesta', 'Cantidad de respuestas'],
        <?php echo $chartData2 ?>
      ]);

      var options = { title: "<?php echo $chartTitle2 ?>" };
      var chart = new google.visualization.PieChart(document.getElementById('chart2'));
      chart.draw(data, options);

      //Grafica 3
      var data = google.visualization.arrayToDataTable([
        ['Respuesta', 'Cantidad de respuestas'],
        <?php echo $chartData3 ?>
      ]);

      var options = { title: "<?php echo $chartTitle3 ?>" };
      var chart = new google.visualization.PieChart(document.getElementById('chart3'));
      chart.draw(data, options);

      //Grafica 4
      var data = google.visualization.arrayToDataTable([
        ['Respuesta', 'Cantidad de respuestas'],
        <?php echo $chartData4 ?>
      ]);

      var options = { title: "<?php echo $chartTitle4 ?>" };
      var chart = new google.visualization.PieChart(document.getElementById('chart4'));
      chart.draw(data, options);
    }
  </script>
  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Gestion_Ponentes\resources\views/Administrador/sesion.blade.php ENDPATH**/ ?>