
<?php $__env->startSection('content'); ?>
  
<div class="col-5 col-md-3">
  <a href="<?php echo e(route('Administrador.sesiones.index')); ?>" 
    class="btn btn-small text-sm normal-case text-light" 
    style="background-color: #da2c4e; border-radius: 15px;">
    <i class="fas fa-caret-left"></i>
    Volver
  </a>
</div>
<div class="row col-10 offset-1">
  <div class="text-center text-lg font-bold col-md-3">Sesion <?php echo e($sesion->idsesion); ?> </div>
  <div class="text-center py-4 col-md-5 text-lg font-bold">Tallerista: <?php echo e($sesion->tallerista); ?> </div>
</div>
<div class="card p-2 p-md-4">
  <div class="card-body">
    <div class="row">
      
      <div class="card-header">
        <table class="table">
          <thead>
            <tr>
              <th>Cuestionario</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><?php echo e($preguntas[0]->nombre_pregunta); ?></td>
            </tr>
            <tr>
              <td><?php echo e($preguntas[1]->nombre_pregunta); ?></td>
            </tr>
            <tr>
              <td><?php echo e($preguntas[2]->nombre_pregunta); ?></td>
            </tr>
            <tr>
              <td><?php echo e($preguntas[3]->nombre_pregunta); ?></td>
            </tr>
          </tbody>
        </table>
        
      </div>

      <div class="card-header p-1 col-lg-12" id="chart1">
          
      </div>
      
      <div class="card-header col-12">
        <div class="table-responsive">
          <table id="tabla_sesion_asistentes" class="table table-striped">
            <caption>Asistentes a la sesi&oacute;n</caption>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombre </th>
                    <th>Ubicación </th>
                    <th class="d-none d-md-table-cell">Departamento </th>
                    <th class="d-none d-md-table-cell">Id sesión </th>
                </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $asistentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($asistente->id_empleado); ?> </th>
                    <td><?php echo e($asistente->nombre_completo); ?></td>
                    <td><?php echo e($asistente->ubicacion); ?></td>
                    <td class="d-none d-md-table-cell"><?php echo e($asistente->departamento); ?></td>
                    <td class="d-none d-md-table-cell"><?php echo e($asistente->idsesion); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <div class="col-12 d-flex justify-content-end p-4">
            <div class="btn-group" role="group">
              <a href="<?php echo e(route('Administrador.asistentes.excel.download' , $sesion->idsesion)); ?>" class="btn" style="background-color: aqua">Exportar</a>
            </div>
          </div>
          
        </div>
      </div>

      
      

      
      <div class="invisible">
        <div class="table-responsive">
          <table id="datatable" class="table table-striped table-sm">
            <thead>
                <tr>
                    <th></th>
                    <th><?php echo e($respuestas[0]->respuesta); ?> </th>
                    <th><?php echo e($respuestas[1]->respuesta); ?> </th>
                    <th><?php echo e($respuestas[2]->respuesta); ?> </th>
                    <th><?php echo e($respuestas[3]->respuesta); ?> </th>
                    <th><?php echo e($respuestas[4]->respuesta); ?> </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    
                    <th>Pregunta_1</th>
                    <td><?php echo e($data1->respuesta_1); ?></td>
                    <td><?php echo e($data1->respuesta_2); ?></td>
                    <td><?php echo e($data1->respuesta_3); ?></td>
                    <td><?php echo e($data1->respuesta_4); ?></td>
                    <td><?php echo e($data1->respuesta_5); ?></td>
                </tr>
                <tr>
                    
                    <th>Pregunta_2</th>
                    <td><?php echo e($data2->respuesta_1); ?></td>
                    <td><?php echo e($data2->respuesta_2); ?></td>
                    <td><?php echo e($data2->respuesta_3); ?></td>
                    <td><?php echo e($data2->respuesta_4); ?></td>
                    <td><?php echo e($data2->respuesta_5); ?></td>
                </tr>
                <tr>
                    
                    <th>Pregunta_3</th>
                    <td><?php echo e($data3->respuesta_1); ?></td>
                    <td><?php echo e($data3->respuesta_2); ?></td>
                    <td><?php echo e($data3->respuesta_3); ?></td>
                    <td><?php echo e($data3->respuesta_4); ?></td>
                    <td><?php echo e($data3->respuesta_5); ?></td>
                </tr>
                <tr>
                    
                    <th>Pregunta_4</th>
                    <td><?php echo e($data4->respuesta_1); ?></td>
                    <td><?php echo e($data4->respuesta_2); ?></td>
                    <td><?php echo e($data4->respuesta_3); ?></td>
                    <td><?php echo e($data4->respuesta_4); ?></td>
                    <td><?php echo e($data4->respuesta_5); ?></td>
                </tr>
            </tbody>
          </table>
        </div>
      </div>
        
      <div class="card-header">
        Comentarios
        <div><?php echo e($sesion->comentario1); ?></div>
        <div><?php echo e($sesion->comentario2); ?></div>
        <div><?php echo e($sesion->comentario3); ?></div>
        <div><?php echo e($sesion->comentario4); ?></div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script>
<script>
  Highcharts.chart('chart1', {
    data: {
        table: 'datatable'
    },
    chart: {
        type: 'column'
    },
    title: {
        text: 'Datos del cuestionario'
    },
    yAxis: {
        allowDecimals: false,
        title: {
            text: 'Cantidad de respuestas'
        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>' +
                this.point.y + ' ' + this.point.name.toLowerCase();
        }
    }
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Gestion_Ponentes\resources\views/Administrador/sesion.blade.php ENDPATH**/ ?>