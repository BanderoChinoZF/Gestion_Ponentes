<div class="container p-2 p-lg-4">
    
    <div class="card-body">
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        <?php $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col">
            <div class="card h-100 p-0">
              <img src="<?php if($a->ruta_imagen): ?>
                  <?php echo e(asset($a->ruta_imagen)); ?>

                <?php else: ?>
                  <?php echo e(asset('img/sin_imagen.png')); ?>

                <?php endif; ?>" alt="" class="img-fluid rounded h-40" style="object-fit: cover;">
              <div class="card-body">
                <div class="d-flex justify-content-between">
                  <label class=""><strong>Sesi&oacute;n</strong></label>
                  <label class=""><?php echo e($a->idsesion); ?></label>
                </div>
                <div class="d-flex justify-content-between">
                  <label class=""><strong>Tallerista</strong></label>
                  <label class=""><?php echo e($a->tallerista); ?></label>
                </div>
                <div class="d-flex justify-content-end">
                  <label class=""><?php echo e($a->fecha); ?></label>
                </div>
              </div>
              <div class="card-footer">
                <a href="<?php echo e(route('Administrador.sesiones.showSesion', $a->idsesion)); ?>" class="btn btn-block" style="background-color: #da2c4e"> detalles</a>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
    
    <br><br><br>
    <div class="card-footer">
      <?php echo e($resultados->links()); ?>

    </div>
</div>
<?php /**PATH D:\xampp\htdocs\Gestion_Ponentes\resources\views/livewire/tallerista-sesiones.blade.php ENDPATH**/ ?>