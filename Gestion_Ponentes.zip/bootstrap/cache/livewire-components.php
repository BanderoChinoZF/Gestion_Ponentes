<?php return array (
  'sesiones' => 'App\\Http\\Livewire\\Sesiones',
  'tallerista-sesiones' => 'App\\Http\\Livewire\\TalleristaSesiones',
);