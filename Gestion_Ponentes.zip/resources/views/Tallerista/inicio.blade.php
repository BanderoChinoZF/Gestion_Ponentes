inicio de los talleristas
